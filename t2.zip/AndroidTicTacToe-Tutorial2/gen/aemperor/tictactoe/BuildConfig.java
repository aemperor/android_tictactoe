/** Automatically generated file. DO NOT MODIFY */
package aemperor.tictactoe;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}